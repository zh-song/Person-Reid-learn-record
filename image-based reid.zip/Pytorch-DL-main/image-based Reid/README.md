## image-based-person-re-Identification-easy
This is an experiment learned from layumi for beginners of person re-identification.

Recording the learning process and the results.
